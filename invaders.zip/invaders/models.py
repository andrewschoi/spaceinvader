"""
Models module for Alien Invaders

This module contains the model classes for the Alien Invaders game. Anything
that you interact with on the screen is model: the ship, the laser bolts, and
the aliens.

Just because something is a model does not mean there has to be a special
class for it. Unless you need something special for your extra gameplay
features, Ship and Aliens could just be an instance of GImage that you move
across the screen. You only need a new class when you add extra features to
an object. So technically Bolt, which has a velocity, is really the only model
that needs to have its own class.

With that said, we have included the subclasses for Ship and Aliens. That is
because there are a lot of constants in consts.py for initializing the
objects, and you might want to add a custom initializer.  With that said,
feel free to keep the pass underneath the class definitions if you do not want
to do that.

You are free to add even more models to this module.  You may wish to do this
when you add new features to your game, such as power-ups.  If you are unsure
about whether to make a new class or not, please ask on Piazza.

Andrew Choi (asc269) Nuri Hong (nh325)
12-7-2021
"""
from consts import *
from game2d import *

# PRIMARY RULE: Models are not allowed to access anything in any module other
# than consts.py.  If you need extra information from Gameplay, then it should
# be a parameter in your method, and Wave should pass it as a argument when it
# calls the method.


class Ship(GSprite):
    """
    A class to represent the game ship.

    At the very least, you want a __init__ method to initialize the ships
    dimensions. These dimensions are all specified in consts.py.

    You should probably add a method for moving the ship.  While moving a
    ship just means changing the x attribute (which you can do directly),
    you want to prevent the player from moving the ship offscreen.  This
    is an ideal thing to do in a method.

    You also MIGHT want to add code to detect a collision with a bolt. We
    do not require this.  You could put this method in Wave if you wanted to.
    But the advantage of putting it here is that Ships and Aliens collide
    with different bolts.  Ships collide with Alien bolts, not Ship bolts.
    And Aliens collide with Ship bolts, not Alien bolts. An easy way to
    keep this straight is for this class to have its own collision method.

    However, there is no need for any more attributes other than those
    inherited by GImage. You would only add attributes if you needed them
    for extra gameplay features (like animation).
    """
    #  IF YOU ADD ATTRIBUTES, LIST THEM BELOW
    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getx(self):
        """
        returns ship x pos
        """
        return self.x

    def gety(self):
        """
        returns ship y pos
        """
        return self.y

    def setx(self, x):
        """
        sets ship x pos

        Parameter x: the new ship x pos
        Precondition: x is a float
        """
        self.x = x

    def setframe(self, frame):
        """
        returns ship frame

        Parameter frame: the new sprite frame
        Precondition: frame is an int
        """
        self.frame = frame

    # INITIALIZER TO CREATE A NEW SHIP
    def __init__(self, xpos = GAME_WIDTH / 2, ypos = SHIP_BOTTOM,
        width = SHIP_WIDTH, height = SHIP_HEIGHT, path = 'ship-strip.png',
        frames = (2,4)):
        """
        creates a ship

        Parameter xpos: ship x pos
        Precondition: xpos is a float

        Parameter ypos: the ship y pos
        Precondition: ypos is a float

        Parameter width: The ship width
        Precondition: width is a float

        Parameter height: the ship height
        Precondition: height is a float

        Parameter path: the ship sprite
        Precondition: path is a sprite
        """
        super().__init__(source = path, format = frames, width = width,
            height = height)
        setattr(self, 'x', xpos)
        setattr(self, 'y', ypos)
        self.frame = 0

    # METHODS TO MOVE THE SHIP AND CHECK FOR COLLISIONS
    def collide(self,bolt):
        """
        Returns True if the alien bolt collides with this ship

        Parameter bolt: The laser bolt to check
        Precondition: bolt is of class Bolt
        """
        corners = bolt.getCorners()

        for corner in corners:
            if self.contains(corner) and not bolt.getisPlayer():
                return True
        return False

    # COROUTINE METHOD TO ANIMATE THE SHIP
    def _animateShip(self):
        """
        animation driver for explode
        USES CODE FROM SAMPLE
        """
        time = 0
        while time < DEATH_SPEED:
            dt = (yield)
            curr = int(time / DEATH_SPEED * SHIP_FRAMES)
            self.frame = curr
            time += dt

    # ADD MORE METHODS (PROPERLY SPECIFIED) AS NECESSARY


class Alien(GSprite):
    """
    A class to represent a single alien.

    At the very least, you want a __init__ method to initialize the alien
    dimensions. These dimensions are all specified in consts.py.

    You also MIGHT want to add code to detect a collision with a bolt. We
    do not require this.  You could put this method in Wave if you wanted to.
    But the advantage of putting it here is that Ships and Aliens collide
    with different bolts.  Ships collide with Alien bolts, not Ship bolts.
    And Aliens collide with Ship bolts, not Alien bolts. An easy way to
    keep this straight is for this class to have its own collision method.

    However, there is no need for any more attributes other than those
    inherited by GImage. You would only add attributes if you needed them
    for extra gameplay features (like giving each alien a score value).
    """
    #  IF YOU ADD ATTRIBUTES, LIST THEM BELOW


    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getx(self):
        """
        returns alien y
        """
        return self.x

    def gety(self):
        """
        returns alien x
        """
        return self.y

    def setx(self, x):
        """
        sets alien x value

        Parameter x: the new alien x pos
        Precondition: x is a float
        """
        self.x = x

    def sety(self, y):
        """
        sets alien y value

        Parameter y: the new alien y pos
        Precondition: y is a float
        """
        self.y = y

    # INITIALIZER TO CREATE AN ALIEN
    def __init__(self, xpos, ypos, width, height, path, frames = (4, 2)):
        """
        Creates an alien

        Parameter xpos: alien x pos
        Precondition: xpos is a float

        Parameter ypos: the alien y pos
        Precondition: ypos is a float

        Parameter width: The alien width
        Precondition: width is a float

        Parameter height: the alien height
        Precondition: height is a float

        Parameter path: the alien sprite
        Precondition: path is a sprite
        """
        super().__init__(source = path, format = frames, width = width,
            height = height)
        setattr(self, 'x', xpos)
        setattr(self, 'y', ypos)
        self.frame = 0

    # METHOD TO CHECK FOR COLLISION (IF DESIRED)
    def collide(self,bolt):
        """
        Returns True if the player bolt collides with this alien

        This method returns False if bolt was not fired by the player.

        Parameter bolt: The laser bolt to check
        Precondition: bolt is of class Bolt
        """
        corners = bolt.getCorners()

        for corner in corners:
            if self.contains(corner) and bolt.getisPlayer():
                return True
        return False


    # ADD MORE METHODS (PROPERLY SPECIFIED) AS NECESSARY


class Bolt(GRectangle):
    """
    A class representing a laser bolt.

    Laser bolts are often just thin, white rectangles. The size of the bolt
    is determined by constants in consts.py. We MUST subclass GRectangle,
    because we need to add an extra (hidden) attribute for the velocity of
    the bolt.

    The class Wave will need to look at these attributes, so you will need
    getters for them.  However, it is possible to write this assignment with
    no setters for the velocities.  That is because the velocity is fixed and
    cannot change once the bolt is fired.

    In addition to the getters, you need to write the __init__ method to set
    the starting velocity. This __init__ method will need to call the __init__
    from GRectangle as a  helper.

    You also MIGHT want to create a method to move the bolt.  You move the
    bolt by adding the velocity to the y-position.  However, the getter
    allows Wave to do this on its own, so this method is not required.
    """
    # INSTANCE ATTRIBUTES:
    # Attribute _velocity: the velocity in y direction
    # Invariant: _velocity is an int or float
    #
    # Attribute _isPlayer: whether a bolt is a player bolt
    # Invariant: _isPlayer is a boolean True/False
    #
    # LIST MORE ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY


    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def gety(self):
        """
        returns bolt y
        """
        return self.y


    def getx(self):
        """
        return bolt x
        """
        return self.x

    def sety(self, y):
        """
        sets bolt y value

        Parameter y: the new bolt y pos
        Precondition: y is a float
        """
        self.y = y

    def getvel(self):
        """
        return bolt vel
        """
        return self._velocity

    def getisPlayer(self):
        """
        returns isPlayer
        """
        return self._isPlayer

    def getCorners(self):
        """
        returns an array of tuples of the corner of the bolt
        """
        corner1 = (self.x - BOLT_WIDTH / 2, self.y - BOLT_HEIGHT / 2)
        corner2 = (self.x + BOLT_WIDTH / 2, self.y - BOLT_HEIGHT / 2)
        corner3 = (self.x - BOLT_WIDTH / 2, self.y + BOLT_HEIGHT / 2)
        corner4 = (self.x + BOLT_WIDTH / 2, self.y + BOLT_HEIGHT / 2)
        return [corner1, corner2, corner3, corner4]



    # INITIALIZER TO SET THE VELOCITY
    def __init__(self, xpos, ypos, velocity, isPlayer,
        width=BOLT_WIDTH, height=BOLT_HEIGHT, fillcolor = 'red'):

        super().__init__(x = xpos, y = ypos, width = width,
            height = height, fillcolor = fillcolor)
        self._velocity = velocity
        self._isPlayer = isPlayer
    # ADD MORE METHODS (PROPERLY SPECIFIED) AS NECESSARY

# IF YOU NEED ADDITIONAL MODEL CLASSES, THEY GO HERE
