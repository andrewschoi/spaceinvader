"""
Subcontroller module for Alien Invaders

This module contains the subcontroller to manage a single level or wave in
the Alien Invaders game.  Instances of Wave represent a single wave. Whenever
you move to a new level, you are expected to make a new instance of the class.

The subcontroller Wave manages the ship, the aliens and any laser bolts on
screen. These are model objects.  Their classes are defined in models.py.

Most of your work on this assignment will be in either this module or
models.py. Whether a helper method belongs in this module or models.py is
often a complicated issue.  If you do not know, ask on Piazza and we will
answer.

Andrew Choi (asc269) Nuri Hong (nh325)
12-7-2021
"""
from game2d import *
from consts import *
from models import *
import random

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Wave is NOT allowed to access anything in app.py (Subcontrollers are not
# permitted to access anything in their parent. To see why, take CS 3152)


class Wave(object):
    """
    This class controls a single level or wave of Alien Invaders.

    This subcontroller has a reference to the ship, aliens, and any laser bolts
    on screen. It animates the laser bolts, removing any aliens as necessary.
    It also marches the aliens back and forth across the screen until they are
    all destroyed or they reach the defense line (at which point the player
    loses). When the wave is complete, you  should create a NEW instance of
    Wave (in Invaders) if you want to make a new wave of aliens.

    If you want to pause the game, tell this controller to draw, but do not
    update.  See subcontrollers.py from Lecture 24 for an example.  This
    class will be similar to than one in how it interacts with the main class
    Invaders.

    All of the attributes of this class ar to be hidden. You may find that
    you want to access an attribute in class Invaders. It is okay if you do,
    but you MAY NOT ACCESS THE ATTRIBUTES DIRECTLY. You must use a getter
    and/or setter for any attribute that you need to access in Invaders.
    Only add the getters and setters that you need for Invaders. You can keep
    everything else hidden.

    """
    # HIDDEN ATTRIBUTES:
    # Attribute _ship: the player ship to control
    # Invariant: _ship is a Ship object or None
    #
    # Attribute _aliens: the 2d list of aliens in the wave
    # Invariant: _aliens is a rectangular 2d list containing Alien objects or None
    #
    # Attribute _bolts: the laser bolts currently on screen
    # Invariant: _bolts is a list of Bolt objects, possibly empty
    #
    # Attribute _dline: the defensive line being protected
    # Invariant : _dline is a GPath object
    #
    # Attribute _lives: the number of lives left
    # Invariant: _lives is an int >= 0
    #
    # Attribute _time: the amount of time since the last Alien "step"
    # Invariant: _time is a float >= 0s
    #
    # You may change any attribute above, as long as you update the invariant
    # You may also add any new attributes as long as you document them.
    # LIST MORE ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    #
    # Attribute _dir: the direction, right is True, left is False
    # Invariant: _dir is a boolean
    #
    # Attribute _alienbolt: rate of alien bolts
    # Invariant: _alienbolt is a float >= 0s and <= BOLT_RATE
    #
    # Attribute _timebolt: time since last alien bolts
    # Invariant: _timebolt: is a float >= 0
    #
    # Attribute _animator: A coroutine for performing an animation
    # Invariant: _animator is a generator-based coroutine (or None)
    #
    # Attribute _shipanimation: is ship animating
    # Invariant: _shipanimation: is a boolean
    #
    # Attribute _pause: is player dead
    # Invariant: _pause: is a boolean
    #
    # Attribute _score: player score
    # Invariant: _score: is an int
    #
    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)

    def getAliens(self):
        """
        return aliens
        """
        return self._aliens

    def getShip(self):
        """
        returns ship
        """
        return self._ship

    def getPause(self):
        """
        returns pause attribute
        """
        return self._pause

    def getLives(self):
        """
        returns lives attribute
        """
        return self._lives

    def getScore(self):
        """
        returns score attribute
        """
        return self._score

    def setLives(self, lives):
        """
        sets live attribute

        Parameter lives: the number of ship lives
        Precondition: lives is an int
        """
        self._lives = lives

    def setPause(self, pause):
        """
        sets pause attribute

        Parameter pause: is the state paused
        Precondition: pause is boolean
        """
        self._pause = pause

    # INITIALIZER (standard form) TO CREATE SHIP AND ALIENS
    def __init__(self):
        """
        sets hidden attributes
        """
        self._setAliens()
        self._ship = Ship()
        self._setdline()
        self._time = 0
        self._dir = True
        self._bolt = []
        self._alienbolt = random.randrange(1, BOLT_RATE)
        self._timebolt = 0
        self._shipanimation = False
        self._alienanimation = False
        self._animator = None
        self._lives = 3
        self._pause = False
        self._score = 0

    # UPDATE METHOD TO MOVE THE SHIP, ALIENS, AND LASER BOLTS
    def update(self, input, dt):
        """
        animates the ship, aliens, and laser bolts

        Parameter input: the keyboard input
        Precondition: input is a GObject attribute

        Parameter dt: the time since the last animation frame
        Precondition: dt is a float

        FROM CLASS SAMPLE
        """
        self._moveShip(input) #moves ship

        if self._time >= ALIEN_SPEED: #moves aliens
            self._moveAliens(self._dir)
            self._time = 0
        self._time += dt

        self.shoot(input, dt)
        self._moveBolt()
        self.alienShoot(dt)
        self.shiphit(dt)
        if self._shipanimation:
            self.explodeShip(dt)

        self.removeAlien()
        self.checkdefense()

    # DRAW METHOD TO DRAW THE SHIP, ALIENS, DEFENSIVE LINE AND BOLTS
    def draw(self, view):
        """
        draws the ship, aliens, defensive line, and bolts

        Parameter view: the view in which to draw the objects
        Precondition: view is an attribute of GameApp
        """
        #draws aliens
        for row in self.getAliens():
            for alien in row:
                if not alien is None:
                    alien.draw(view)
        #draws ship
        self._ship.draw(view)
        #draws defensive line
        self._dline.draw(view)
        #draws bolts
        for bolt in self._bolt:
            bolt.draw(view)

    # HELPER METHODS FOR COLLISION DETECTION
    def _setAliens(self):
        """
        creates a 2d list of alien objects and sets _aliens
        """
        list = []
        xpos = ALIEN_H_SEP +ALIEN_WIDTH/2
        ypos = GAME_HEIGHT - (ALIEN_CEILING + (ALIEN_ROWS - 1) * (ALIEN_V_SEP
            + ALIEN_HEIGHT) + ALIEN_HEIGHT / 2)
        width = ALIEN_WIDTH
        height = ALIEN_HEIGHT
        image = ALIEN_IMAGES

        for rows in range(ALIEN_ROWS):
            row = []

            if rows % 2 == 0:
                type = rows % 3
            for columns in range(ALIENS_IN_ROW):
                row.append(Alien(xpos,ypos,width,height,image[type]))
                xpos += width + ALIEN_H_SEP
            xpos = ALIEN_H_SEP +ALIEN_WIDTH/2
            list.append(row)
            ypos += height + ALIEN_V_SEP

        self._aliens = list

    def _setdline(self):
        """
        creates the defensive line and sets _dline
        """
        line = GPath(linewidth=2,
            points=[0,DEFENSE_LINE,GAME_WIDTH,DEFENSE_LINE], linecolor="black")
        self._dline = line

    def _moveShip(self, input):
        """
        moves ship

        Parameter input: the keyboard input
        Precondition: input is a GObject attribute
        """
        da = 0
        if input.is_key_down('right'):
            da += SHIP_MOVEMENT
        if input.is_key_down('left'):
            da -= SHIP_MOVEMENT
        if self._ship.getx() > GAME_WIDTH - SHIP_WIDTH / 2:
            self._ship.setx(GAME_WIDTH - SHIP_WIDTH / 2)
        elif self._ship.getx() < SHIP_WIDTH / 2:
            self._ship.setx(SHIP_WIDTH / 2)
        else:
            self._ship.setx(self._ship.getx() + da)

    def _moveAliens(self, dir):
        """
        moves aliens

        Parameter dir: the direction of the alien movement T - Right F - Left
        Precondition: dir is boolean
        """
        if dir:
            for rows in self._aliens:
                for alien in rows:
                    if not alien is None:
                        alien.setx(alien.getx() + ALIEN_H_WALK)
        else:
            for rows in self._aliens:
                for alien in rows:
                    if not alien is None:
                        alien.setx(alien.getx() - ALIEN_H_WALK)

        if self._xmin() <= ALIEN_H_SEP + ALIEN_WIDTH / 2 or self._xmax() >= \
            GAME_WIDTH - ALIEN_WIDTH - ALIEN_H_SEP:

            for rows in self._aliens:
                for alien in rows:
                    if not alien is None:
                        alien.sety(alien.gety() - ALIEN_V_WALK)
            self._dir = not self._dir

    def _xmin(self):
        """
        finds minimum alien x value
        """
        min = GAME_WIDTH
        for row in self._aliens:
            for alien in row:
                if not alien is None and alien.x < min:
                    min = alien.x
        return min

    def _xmax(self):
        max = 0
        for row in self._aliens:
            for alien in row:
                if not alien is None and alien.x > max:
                    max = alien.x
        return max

    def _moveBolt(self):
        """
        moves bolts on screen
        """
        for bolt in self._bolt:
            if bolt.getisPlayer():
                bolt.sety(bolt.gety() + bolt.getvel())
            else:
                bolt.sety(bolt.gety() - bolt.getvel())

    def shoot(self, input, dt):
        """
        returns a bolt on key press at ship coordinates

        Parameter input: the keyboard input
        Precondition: input a GObject attribute

        Parameter dt: the time since the last animation frame
        Precondition: dt is a float

        USES CODE FROM CLASS SAMPLE
        """
        curr_keys = input.key_count

        # Only change if we have just pressed the keys this animation frame
        change = curr_keys > 0 and input.keys[0] == 'up'

        if change and self._isPlayerBolt():
            self._bolt.append(Bolt(self.getShip().getx(),
                self.getShip().gety(), BOLT_SPEED, True))

    def alienShoot(self, dt):
        """
        returns a bolt at a random alien's coordinates

        Parameter dt: the time since the last animation frame
        Precondition: dt is a float
        """
        alien = self._whichAlien()

        if self._canFire(dt) and self._isAlien():
            alienbolt = Bolt(alien.getx(), alien.gety(), BOLT_SPEED, False)
            self._bolt.append(alienbolt)

    def _isPlayerBolt(self):
        """
        checks if theres only one player bolt on screen
        """
        count= 0

        for index, bolt in enumerate(self._bolt):
            if bolt.getisPlayer() and bolt.gety() > GAME_HEIGHT:
                self._bolt.pop(index)
        for bolt in self._bolt:
            if bolt.getisPlayer():
                count += 1

        if count < 1:
            return True
        return False

    def _canFire(self, dt):
        """
        return true if ready to fire

        Parameter dt: the time since the last animation frame
        Precondition: dt is a float
        """
        self._timebolt += dt
        if self._timebolt > self._alienbolt:
            self._timebolt = 0
            return True
        return False

    def _whichAlien(self):
        """
        picks a nonempty row of aliens and returns an alien in that column
        """
        index = random.randrange(0, ALIENS_IN_ROW)
        while self._isEmpty(index) and self._isAlien():
            index = random.randrange(0, ALIENS_IN_ROW)
        return self._findBottom(index)

    def _isAlien(self):
        """
        Returns True is there is an alien
        """
        for row in self._aliens:
            for alien in row:
                if not alien is None:
                    return True
        return False

    def _isEmpty(self, index):
        """
        checks if the alien column is empty

        Parameter index: the column index
        Precondition: index is an int
        """
        empty = True
        for alien in self._aliens:
            if not alien[index] == None:
                return False
        return empty

    def _isRowEmpty(self,index):
        """
        checks if the alien row is empty

        Parameter index: the row index
        Precondition: index is an int
        """
        empty = True
        for alien in self._aliens[index]:
            if not alien is None:
                return False
        return empty

    def _findBottom(self, index):
        """
        returns bottommost alien in a column

        Parameter index: the column index
        Precondition: index is an int
        """
        bottom = self._aliens[0][index]
        for x in range(ALIEN_ROWS):
            if not self._aliens[x][index] is None:
                return self._aliens[x][index]
        return bottom

    def removeAlien(self):
        """
        removes alien that collide with player bolts
        """
        for i, row in enumerate(self._aliens):
            for j, alien in enumerate(row):
                for index, bolt in enumerate(self._bolt):
                    if not alien is None and alien.collide(bolt):
                        self._alienanimation = True
                        self._aliens[i][j] = None
                        self._bolt.pop(index)
                        self._score += 10

    def shiphit(self, dt):
        """
        removes ship that collide with alien bolt

        Parameter dt: the time since the last animation frame
        Precondition: dt is a float
        """
        for index, bolt in enumerate(self._bolt):
            if not self._ship is None and self._ship.collide(bolt):
                self._bolt.pop(index)
                self._shipanimation = True

    def explodeShip(self, dt):
        """
        sets ship image

        Parameter dt: the time since the last animation frame
        Precondition: dt is a float
        USES CODE FROM SAMPLE
        """
        if not self._animator is None:      # We have something to animate
            try:
                self._animator.send(dt)

            except StopIteration:
                self._animator = None     # Stop animating
                self._shipanimation = False
                self._pause = True
                self._lives -= 1
                if self._lives > 0:
                    self._ship.setframe(0)
        else:
            self._animator = self._ship._animateShip()
            next(self._animator) # Start up the animator

    def checkdefense(self):
        """
        returns True if aliens have crossed the defensive path
        """
        for row in self._aliens:
            for alien in row:
                if not alien is None and alien.gety() < DEFENSE_LINE:
                    self._shipanimation = True
                    return True
        return False

    def canContinue(self):
        """
        checks if player still has more lives
        """
        if self._lives >= 1:
            return True
        return False

    def checkwin(self):
        """
        checks if player killed all aliens
        """
        return not self._isAlien() and not self.checkdefense()
